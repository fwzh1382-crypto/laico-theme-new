<?php

/**
 * Laico Design — Sage Theme Setup (`app/setup.php`).
 */

declare(strict_types=1);

namespace App;

use App\Services\ThemeOptions;
use App\Support\ViteAssets;

/**
 * Register theme assets on the frontend (zero external CDN dependencies).
 */
add_action('wp_enqueue_scripts', static function (): void {
    $cssUrl = ViteAssets::entryCss('resources/css/app.css');
    if ($cssUrl !== null) {
        wp_enqueue_style('laico-styles', $cssUrl, [], ViteAssets::assetVersion('resources/css/app.css'));
    }

    $jsUrl = ViteAssets::entryJs('resources/js/app.js');
    if ($jsUrl !== null) {
        $englishEnabled = ThemeOptions::isEnglishEnabled();
        $stealthLogin = (class_exists('NSH_Stealth') && method_exists('NSH_Stealth', 'login_slug'))
            ? (string) \NSH_Stealth::login_slug()
            : '';
        $stealthAdmin = (class_exists('NSH_Stealth') && method_exists('NSH_Stealth', 'admin_slug'))
            ? (string) \NSH_Stealth::admin_slug()
            : '';

        wp_enqueue_script('laico-app', $jsUrl, [], ViteAssets::assetVersion('resources/js/app.js'), true);
        wp_localize_script('laico-app', 'laicoConfig', [
            'restUrl' => esc_url_raw(rest_url('laico/v1/submissions')),
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('laico_public_form'),
            'defaultLang' => $englishEnabled ? (string) ThemeOptions::get('default_language', 'fa') : 'fa',
            'enableLangSwitcher' => $englishEnabled,
            'prefetch' => (bool) ThemeOptions::get('opt_instant_page_prefetch', true),
            'pageLoader' => (bool) ThemeOptions::get('opt_page_loader', true),
            'excludePaths' => array_values(array_filter([
                '/wp-admin',
                '/wp-login',
                $stealthLogin !== '' ? '/' . trim($stealthLogin, '/') : '',
                $stealthAdmin !== '' ? '/' . trim($stealthAdmin, '/') : '',
            ])),
            'i18n' => \App\Support\Bilingual::dictionary(),
        ]);
    }
}, 20);

/**
 * Register Block Editor styles & scripts.
 */
add_action('enqueue_block_editor_assets', static function (): void {
    $editorCss = ViteAssets::entryCss('resources/css/editor.css');
    if ($editorCss !== null) {
        wp_enqueue_style('laico-editor-styles', $editorCss, [], null);
    }

    $editorJs = ViteAssets::entryJs('resources/js/editor.js');
    if ($editorJs !== null) {
        wp_enqueue_script('laico-editor-scripts', $editorJs, ['wp-blocks', 'wp-dom-ready'], null, true);
    }
});

/**
 * Register initial theme supports, image sizes, and navigation menus.
 */
add_action('after_setup_theme', static function (): void {
    load_theme_textdomain('laico-sage', get_template_directory() . '/resources/lang');

    remove_theme_support('block-templates');

    register_nav_menus([
        'primary_navigation' => 'منوی اصلی هدر (Primary Navigation)',
        'footer_navigation' => 'منوی ستون اول فوتر (Footer Navigation)',
    ]);

    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('html5', [
        'caption',
        'comment-form',
        'comment-list',
        'gallery',
        'search-form',
        'script',
        'style',
    ]);

    // High-resolution Hero & Portfolio image sizes
    add_image_size('laico-hero', 1920, 1080, false);
    add_image_size('laico-card', 1200, 900, true);
}, 20);
